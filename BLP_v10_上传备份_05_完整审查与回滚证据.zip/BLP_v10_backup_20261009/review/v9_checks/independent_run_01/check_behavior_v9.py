from pathlib import Path
import json,hashlib,tomllib,re
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=U/'review/v9_checks/independent_run_01';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((U/'BEHAVIOR_V9_FREEZE.json').read_text('utf8'));assert h(U/'BEHAVIOR_V9_FREEZE.json')=='35194a38c3775f16e94072f8a4e2fdb8deb171a338dba27a0c2568857a65e618'
identity=[]
for r in f['files']:
 p=U/r['path']; assert h(p)==r['sha256'] and p.stat().st_size==r['bytes'],r;identity.append(r)
summary={};errors=[]
for arm in ['E','F']:
 x=json.loads((U/f'behavior/fresh_v9/{arm}/RUN.json').read_text('utf8'));procs=x.get('process_events',x.get('processes',[]));print(arm,'PROC KEYS',[list(v) for v in procs[:2]])
 print(arm,'FAILURES',json.dumps(x.get('original_failures',x.get('all_raw_failures')),ensure_ascii=False))
 reads=x.get('actual_read_records',x.get('explicit_text_reads',[]));print(arm,'READS',len(reads))
 # Preserve actual record shape and missing raw channels; do not infer a child exit from shell.
 summary[arm]={'status':x['status'],'processes':[ {k:e.get(k) for k in ['label','name','pid','exit_status','started','finished','stdout_path','stderr_path']} for e in procs], 'failures':x.get('original_failures',x.get('all_raw_failures')),'semantic_reads':reads,'questions':x['questions']}
 for e in procs:
  for stream in ['stdout','stderr']:
   p=e.get(stream+'_path');pin=e.get(stream+'_sha256')
   if p and pin:assert h(Path(p))==pin,(arm,e.get('label'),stream)
 for q,limit in [('Q1',1400),('Q2',1400),('Q3',700)]:
  text=(U/f'behavior/fresh_v9/{arm}/{q}.md').read_text('utf8');assert len(re.findall('[\u4e00-\u9fff]',text))<=limit
# Direct TOML parsing is only syntax/config-reference validation, not native execution.
t=tomllib.loads((U/'candidate_v9/agents/blp-professor.toml').read_text('utf8'));assert t['name']=='blp_professor'
b=json.loads((U/'browser_v9/RENDER_RESULT.json').read_text('utf8'));assert len(b['records'])==18 and len(b['pages'])==9
for r in b['records']:assert r['pass'] and r['merror']==0 and not r['rawTeXOutsideCode'] and h(Path(r['source']))==r['source_sha256'] and h(Path(r['html']))==r['html_sha256']
math=sum(r['math'] for r in b['records'] if r['width']==1200);assert math==123
result={'freeze_sha256':h(U/'BEHAVIOR_V9_FREEZE.json'),'files_reopened_checked':len(identity),'arms':summary,'render':{'documents':9,'views':18,'mathml_unique_document_count':math,'source_html_hashes_reopened':True,'boundary':'Parent actual Chromium observations checked against frozen files; reviewer did not claim independently browsing all 18 views'},'TOML':{'parsed':True,'name':t['name']},'scope':'new v9 generic answers only; no quality score inferred from COMPLETE/PASS'}
(R/'behavior_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(R/'review_tool_errors.json').write_text(json.dumps({'errors':[{'tool_chunk':'921313','exit_status':1,'type':'TypeError','literal_error':"TypeError: 'NoneType' object is not iterable",'source':'reviewer exploratory output formatter attempted iterating absent E.processes field; frozen sources untouched','corrected_by':'this shape-aware behavior checker actual exit0 if successful'}]},ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('289 frozen identities and behavior/render/source references valid')
