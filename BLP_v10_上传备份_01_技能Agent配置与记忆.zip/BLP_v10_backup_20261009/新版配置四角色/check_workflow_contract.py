"""Deterministic configuration-contract check, not an LLM quality score."""
import hashlib
import json
import sys
import tomllib
import zipfile

with zipfile.ZipFile(sys.argv[1]) as z:
    names = set(z.namelist())
    root = 'skills/blp-project-professor/'
    case = json.load(open(sys.argv[2], encoding='utf8'))
    policy_path = root + 'references/operating-policy.json'
    if policy_path not in names:
        print(json.dumps({'status': 'UNMET_NEW_WORKFLOW_CONTRACT', 'reason': 'No explicit versioned mode/ranking policy in original configuration', 'quality_score': None}))
        sys.exit(3)
    policy = json.loads(z.read(policy_path))
    decisions = []
    for row in case['requests']:
        actual = policy['mode_by_task'].get(row['task'], policy['default_mode'])
        decisions.append({'task': row['task'], 'selected': actual, 'expected': row['expected_mode'], 'matches': actual == row['expected_mode']})
    config = tomllib.loads(z.read('agents/blp-project-professor.toml').decode('utf8'))
    contract = z.read(root + 'references/agent-contract.md').decode('utf8')
    text = config['developer_instructions']
    checks = {
        'routing_cases': all(v['matches'] for v in decisions),
        'conditional_ranking': policy['recommendation']['ranking'] == 'conditional',
        'requires_useful_next_action': policy['recommendation']['requires_next_action'] is True,
        'unidentified_fallback_not_point_claim': policy['recommendation']['unidentified_fallback'] == 'restricted_model_or_bounds_or_sensitivity',
        'two_roles_distinct': policy['roles']['general'] != policy['roles']['project'],
        'no_automatic_claude_sync': policy['source_control']['mirror_write'] == 'explicit_authorization_only',
        'toml_loads_single_contract': (policy['source_control']['canonical_source'] + '/references/agent-contract.md') in text and contract not in text,
        'contract_hash_pin_matches': policy['source_control']['contract_sha256'] == hashlib.sha256(contract.encode('utf8')).hexdigest(),
        'new_references_reachable': all(root + x in names for x in policy['references']),
    }
    if 'agents/blp-professor.toml' in names:
        general=tomllib.loads(z.read('agents/blp-professor.toml').decode('utf8'))
        checks['general_agent_loads_general_skill']='/skills/blp-model-building/SKILL.md' in general['developer_instructions']
        checks['general_has_composition_and_source_graph']=all('skills/blp-model-building/references/'+n in names for n in ['构造与组合协议.md','模块集成图.md','文献模块来源账本.json'])
    result = {'status': 'PASS' if all(checks.values()) else 'FAIL', 'kind': 'configuration_contract_not_research_behavior_or_score', 'checks': checks, 'decisions': decisions, 'policy_sha256': hashlib.sha256(z.read(policy_path)).hexdigest()}
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if all(checks.values()) else 4)
