"""Independent v8 audit: never mutates frozen inputs or producer fixtures."""
from pathlib import Path
import base64, copy, hashlib, importlib.util, json, os, shutil, subprocess, sys, datetime

U = Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008')
R = U/'review'/'v8_support'/'independent_run_01'/'technical_checks'
R.mkdir()
C = U/'candidate_v8'
D = U/'dependencies_v6'
PY = Path(sys.executable)
CPIN = 'fa7e5badd651fa678eefc9756566f945826c53d17775f26a383dc3a1b3129538'
DPIN = 'd56e07903ec04c73e04235a3752132020f676a429bd9c9796b11d33d3bb57d8c'
EVENTS, CHECKS = [], []
def h(b): return hashlib.sha256(b).hexdigest()
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def check(name, passed, observed):
    CHECKS.append({'name':name,'passed':bool(passed),'observed':observed})
def run(label, command, cwd=R):
    p=subprocess.run(list(map(str,command)),cwd=str(cwd),capture_output=True,timeout=180)
    row={'label':label,'command_array':list(map(str,command)),'cwd':str(cwd),'exit_status':p.returncode,
         'literal_stdout':p.stdout.decode('utf8',errors='replace'),'literal_stderr':p.stderr.decode('utf8',errors='replace'),
         'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode()}
    EVENTS.append(row)
    dump(R/'caller_events.json',EVENTS)
    (R/(label+'.stdout.bin')).write_bytes(p.stdout); (R/(label+'.stderr.bin')).write_bytes(p.stderr)
    return row
def guard(root=C,dep=D,manifest=U/'CANDIDATE_V8_MANIFEST.json',pin=CPIN,dpin=DPIN,out=None):
    return [PY,'-I','-B',root/'scripts'/'runtime_guard.py','--root',root,'--manifest',manifest,'--manifest-sha256',pin,
            '--dependency-root',dep,'--dependency-manifest',dep/'MANIFEST.json','--dependency-manifest-sha256',dpin,
            '--mode','audit','--out',out]
def treehash(root): return {str(p.relative_to(root)):h(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
def repin(root, manifest):
    rows=json.loads(manifest.read_text('utf8'))
    for row in rows:
        b=(root/row['path']).read_bytes(); row.update(sha256=h(b),bytes=len(b))
    dump(manifest,rows)
    return h(manifest.read_bytes())
def clone(label):
    dest=R/'sandbox'/label; dest.mkdir(parents=True)
    rc=dest/'candidate'; rd=dest/'dependencies'; shutil.copytree(C,rc); shutil.copytree(D,rd)
    for tree in (rc,rd):
        for p in tree.rglob('*'):
            if p.is_file(): p.chmod(0o600)
    mf=dest/'MANIFEST.json'; shutil.copyfile(U/'CANDIDATE_V8_MANIFEST.json',mf); mf.chmod(0o600)
    return dest,rc,rd,mf

frozen_before={'candidate':treehash(C),'dependency':treehash(D),'candidate_manifest':h((U/'CANDIDATE_V8_MANIFEST.json').read_bytes())}
dump(R/'frozen_before.json',frozen_before)
check('frozen_manifest_pins', frozen_before['candidate_manifest']==CPIN and h((D/'MANIFEST.json').read_bytes())==DPIN, {'candidate':frozen_before['candidate_manifest'],'dependency':h((D/'MANIFEST.json').read_bytes())})

positive=run('guard_positive',guard(out=R/'guard_positive'))
e=json.loads((R/'guard_positive'/'event.json').read_text('utf8'))
check('real_frozen_guard',positive['exit_status']==0 and e['full_preflight'] and len(e['candidate']['checked'])==17 and len(e['dependency']['checked'])==82 and [v['exit_status'] for v in e['child_events']]==[0,0], {'caller_exit':positive['exit_status'],'event_status':e['status'],'child_exits':[v['exit_status'] for v in e['child_events']]})
old=treehash(R/'guard_positive')
repeat=run('guard_reused_out',guard(out=R/'guard_positive'))
check('guard_same_out_refused_unchanged',repeat['exit_status']==2 and old==treehash(R/'guard_positive'),repeat)
badpin=run('guard_wrong_manifest_pin',guard(pin='0'*64,out=R/'guard_wrong_manifest_pin'))
e=json.loads((R/'guard_wrong_manifest_pin'/'event.json').read_text('utf8'))
check('wrong_manifest_stops_before_children',badpin['exit_status']==2 and not e['child_events'],e['error'])
dest,rc,rd,mf=clone('dependency_mismatch')
(rd/'bridge'/'INDEX.md').write_bytes((rd/'bridge'/'INDEX.md').read_bytes()+b'\nindependent negative fixture\n')
v=run('guard_dependency_mismatch',guard(rc,rd,mf,out=dest/'out'))
e=json.loads((dest/'out'/'event.json').read_text('utf8'))
check('dependency_mismatch_stops_before_children',v['exit_status']==2 and not e['child_events'],e['error'])
dest,rc,rd,mf=clone('runtime_mismatch')
envpath=rc/'skills/blp-project-professor/references/runtime-environment.json'
env=json.loads(envpath.read_text('utf8')); env['python']['version']='0.0.0'; dump(envpath,env)
pin=repin(rc,mf)
v=run('guard_runtime_mismatch',guard(rc,rd,mf,pin,out=dest/'out'))
e=json.loads((dest/'out'/'event.json').read_text('utf8'))
check('runtime_mismatch_stops_before_children',v['exit_status']==2 and not e['child_events'] and 'Python version mismatch' in e['error'],e['error'])
dest,rc,rd,mf=clone('child_failure')
(rc/'scripts/scaled_rank_checks.py').write_text("import sys\nprint('deliberate independent failure',file=sys.stderr)\nsys.exit(9)\n",encoding='utf8')
pin=repin(rc,mf)
v=run('guard_child_failure',guard(rc,rd,mf,pin,out=dest/'out'))
e=json.loads((dest/'out'/'event.json').read_text('utf8'))
check('numerical_failure_stops_second_child',v['exit_status']==3 and len(e['child_events'])==1 and e['child_events'][0]['exit_status']==9 and not e['full_preflight'],e['child_events'])

import numpy as np
spec=importlib.util.spec_from_file_location('independent_rank',C/'scripts/scaled_rank_checks.py'); rank=importlib.util.module_from_spec(spec); spec.loader.exec_module(rank)
tests=[('ordinary',np.array([[1.,0.],[0.,1.],[1.,1.]]),2),('upper',np.array([[1.7e308,0.],[0.,1.7e308],[1.7e308,1.7e308]]),2),('subnormal',np.array([[1e-320,0.],[0.,1e-320],[1e-320,1e-320]]),2),('wide',np.array([[1.,0.,1.],[0.,1.,1.]]),2),('rankone',np.array([[1.,2.],[2.,4.]]),1)]
rankrows=[]
for label,matrix,expected in tests:
    value=rank.rank_diagnostics(matrix); json.dumps(value,allow_nan=False); rankrows.append({'label':label,'diagnostics':value})
    check('independent_rank_'+label,value['standardized']['rank']==expected,{'standardized_rank':value['standardized']['rank'],'full_column_rank':value['standardized']['full_column_rank']})
for label,values in [('complex',np.array([[1+2j,2],[3,4]])),('zero_complex',np.array([[1+0j,2],[3,4]])),('object_complex',np.array([[np.complex128(1+0j),2],[3,4]],dtype=object)),('ragged',[[1],[1,2]]),('nonfinite',[[float('inf'),2],[3,4]])]:
    try: rank.rank_diagnostics(values)
    except ValueError as exc: check('independent_reject_'+label,True,str(exc))
    else: check('independent_reject_'+label,False,'accepted invalid input')
dump(R/'independent_rank.json',rankrows)

# Independent nonlinear choices, gradient finite differences, BLP inversion,
# same-type removal and heterogeneous-alpha welfare; not empirical estimation.
w=np.array([.15,.25,.6]); alpha=np.array([.2,.8,2.0]); p=np.array([1.4,2.1,2.8]); v=np.array([[.2,.9,1.1],[1.1,.3,.4],[.6,.5,.8]])
def probs(prices,delta=None):
    values=v-alpha*prices[:,None] if delta is None else delta[:,None]+mu
    mx=np.maximum(0,values.max(axis=0)); ex=np.exp(values-mx); den=np.exp(-mx)+ex.sum(axis=0)
    return ex/den,np.exp(-mx)/den
q,o=probs(p); s=q@w
J=np.array([[-np.sum(w*alpha*q[j]*((j==k)-q[k])) for k in range(3)] for j in range(3)])
eps=1e-5; fd=np.column_stack([(probs(p+eps*np.eye(3)[k])[0]@w-probs(p-eps*np.eye(3)[k])[0]@w)/(2*eps) for k in range(3)])
check('independent_price_gradient',np.max(abs(J-fd))<1e-9 and np.all(np.diag(J)<0),float(np.max(abs(J-fd))))
delta_true=(v-alpha*p[:,None])@w; mu=(v-alpha*p[:,None])-delta_true[:,None]; delta=np.zeros(3)
for it in range(10000):
    update=np.log(s)-np.log(probs(p,delta)[0]@w); delta+=update
    if max(abs(update))<1e-13: break
check('independent_fixed_mu_inversion',max(abs(delta-delta_true))<1e-11,{'iterations':it+1,'max_error':float(max(abs(delta-delta_true)))})
scale=np.array([1.,1.4,.7]); JA=J*scale[None,:]; O=np.ones((3,3)); mark=np.linalg.solve(-O*JA.T,s)
check('independent_wrong_transpose_refuted',max(abs(s+(O*JA.T)@mark))<1e-12 and max(abs(s+(O*JA)@mark))>1e-3,{'correct_residual':float(max(abs(s+(O*JA.T)@mark))),'wrong_residual':float(max(abs(s+(O*JA)@mark)))})
joint=np.sum(w*q[0]*q[1]/(1-q[0])); wrong=np.sum(w*q[0])*np.sum(w*q[1]/(1-q[0])); buy=1-o; WB=w*buy/(w@buy)
buyer_joint=np.sum(WB*(q[0]/buy)*q[1]/(1-q[0])); buyer_wrong=np.sum(w*(q[0]/buy)*q[1]/(1-q[0]))
check('independent_same_type_and_buyer_weights',abs(joint-wrong)>1e-4 and abs(buyer_joint-joint/(w@buy))<1e-12 and abs(buyer_joint-buyer_wrong)>1e-4,{'joint':float(joint),'product_of_integrals':float(wrong),'buyer_joint':float(buyer_joint),'unweighted_buyer_wrong':float(buyer_wrong)})
def money(prices):
    values=v-alpha*prices[:,None]; mx=np.maximum(0,values.max(axis=0)); lse=mx+np.log(np.exp(-mx)+np.exp(values-mx).sum(axis=0)); return float(w@(lse/alpha))
g=(money(p+eps*np.eye(3)[0])-money(p-eps*np.eye(3)[0]))/(2*eps)
H=-(q*np.log(q)).sum(axis=0)-o*np.log(o); experience=float(w@(((q*(v-alpha*p[:,None])).sum(axis=0)+H)/alpha))
check('independent_money_and_true_belief_experience',abs(g+s[0])<1e-9 and abs(experience-money(p))<1e-12,{'price_derivative':g,'negative_share':float(-s[0]),'experience':experience,'decision':money(p)})

def dispatch(cp,out): return [PY,'-I','-B',C/'scripts/dispatch_checkpoint.py','--checkpoint',cp,'--out',out]
dr=R/'dispatcher_fixtures'; dr.mkdir()
work=dr/'storedcwd'; work.mkdir(); (work/'relative_input.txt').write_text('relative fixture payload',encoding='utf8')
child=work/'runner.py'; child.write_text("from pathlib import Path\nimport os,json,sys\nprint(json.dumps({'cwd':os.getcwd(),'payload':Path(sys.argv[1]).read_text('utf8')}))\n",encoding='utf8')
cp=dr/'checkpoint.json'; obj=dr/'active'; obj.mkdir()
base={'ACTIVE_OBJECT':str(obj),'LAST_CONFIRMED_RESULT':{'completed':['baseline_kept'],'hash':'unchanged'},'NEXT_EXECUTABLE_ACTION':{'command_array':[str(PY),'-B','runner.py','relative_input.txt'],'cwd':str(work),'status':'pending'},'INPUT_PATHS':['relative_input.txt'],'ACCEPTANCE_EVENT':'read relative input from stored cwd','completed_results':{'baseline':'do not rerun'}}
dump(cp,base); before=cp.read_bytes(); r=run('dispatcher_relative_cwd',dispatch(cp,dr/'run'))
e=json.loads((dr/'run'/'command_execution.json').read_text('utf8')); payload=json.loads(e['literal_stdout'])
check('dispatcher_relative_cwd_and_completed_preservation',r['exit_status']==0 and payload['cwd']==str(work) and payload['payload']=='relative fixture payload' and cp.read_bytes()==before and e['bound_fields']['LAST_CONFIRMED_RESULT']==base['LAST_CONFIRMED_RESULT'],e)
old=treehash(dr/'run'); r=run('dispatcher_same_out',dispatch(cp,dr/'run'))
check('dispatcher_same_out_refused_unchanged',r['exit_status']==73 and old==treehash(dr/'run'),r)
completed=copy.deepcopy(base); completed['NEXT_EXECUTABLE_ACTION']['completed']=True; cp2=dr/'completed.json'; dump(cp2,completed)
r=run('dispatcher_completed_refused',dispatch(cp2,dr/'completed_run')); e=json.loads((dr/'completed_run'/'command_execution.json').read_text('utf8'))
check('dispatcher_completed_not_rerun',r['exit_status']==64 and e['started']==False and e['checkpoint_unchanged'],e['controller_error'])
meta=dr/'template.json'; ident={'candidate':'v6','run':'independent'}; m={'success':True,'identity':ident,'command_array':[str(PY),'-B','runner.py','relative_input.txt'],'cwd':str(work)}; dump(meta,m)
b=copy.deepcopy(base); b['identity']=ident; b['controller_command_metadata_path']=str(meta); b['NEXT_EXECUTABLE_ACTION']['command_array']=[str(PY),'-c',"raise Exception('pending fallback must not run')"]
cp3=dr/'template_checkpoint.json'; dump(cp3,b); r=run('dispatcher_template',dispatch(cp3,dr/'template_run')); e=json.loads((dr/'template_run'/'command_execution.json').read_text('utf8'))
check('dispatcher_successful_template_used',r['exit_status']==0 and e['command_selection']['template_applied'] and e['actual_cwd']==str(work),e['command_selection'])

frozen_after={'candidate':treehash(C),'dependency':treehash(D),'candidate_manifest':h((U/'CANDIDATE_V8_MANIFEST.json').read_bytes())}
check('all_frozen_bytes_stayed_unchanged',frozen_before==frozen_after,{'candidate_files':len(frozen_after['candidate']),'dependency_including_manifest':len(frozen_after['dependency'])})
dump(R/'frozen_after.json',frozen_after)
dump(R/'independent_checks.json',{'scope':'actual local process observations and independent synthetic falsification, not empirical IV/GMM/agent universal performance','checks':CHECKS,'all_passed':all(x['passed'] for x in CHECKS),'events_path':str(R/'caller_events.json')})
print(json.dumps({'checks':len(CHECKS),'all_passed':all(x['passed'] for x in CHECKS),'failed':[x['name'] for x in CHECKS if not x['passed']]},ensure_ascii=False))


