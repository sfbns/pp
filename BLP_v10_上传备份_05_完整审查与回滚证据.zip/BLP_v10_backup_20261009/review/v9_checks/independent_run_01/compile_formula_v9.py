from pathlib import Path
import json,subprocess,hashlib,re
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=U/'review/v9_checks/independent_run_01/formula_rebuild';R.mkdir();rows=json.loads((U/'formula_v9_rebuild/COMMAND_EVENTS.json').read_text('utf8'));ev=[]
for i,e in enumerate(rows,1):
 cmd=e['command_array'].copy();n=cmd.index('--output')+1;old=Path(cmd[n]);out=R/old.name;cmd[n]=str(out)
 p=subprocess.run(cmd,cwd=R,capture_output=True);(R/f'{i}.stdout.bin').write_bytes(p.stdout);(R/f'{i}.stderr.bin').write_bytes(p.stderr)
 raw=out.read_bytes();x={'source':e['source'],'command_array':cmd,'exit_status':p.returncode,'literal_stdout':p.stdout.decode('utf8',errors='replace'),'literal_stderr':p.stderr.decode('utf8',errors='replace'),'html':str(out),'sha256':hashlib.sha256(raw).hexdigest(),'byte_equal_parent_actual_compile':raw==old.read_bytes(),'MathML_count':len(re.findall(rb'<math\b',raw)),'merror_count':len(re.findall(rb'<merror\b',raw))};ev.append(x);assert p.returncode==0 and x['byte_equal_parent_actual_compile'] and x['merror_count']==0
(R/'event.json').write_text(json.dumps({'events':ev,'unique_math_count':sum(x['MathML_count'] for x in ev),'view_boundary':'independent reopened one actual generic_390 PNG, not independent browser rerun; parent actual 18-view records validated by hashes'},ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('own 9 real Pandoc exits0; all exact HTML; MathML',sum(x['MathML_count'] for x in ev))
