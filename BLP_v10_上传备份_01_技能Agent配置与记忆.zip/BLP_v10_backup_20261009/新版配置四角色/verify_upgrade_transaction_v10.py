"""Verify a versioned bundle; never modify installed or frozen source files."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys

U = Path(__file__).resolve().parent
G = Path(r'C:\Users\于舒奕\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git')
work = U / 'transaction_work_v10'
work.mkdir(exist_ok=True)
env = os.environ.copy()
for key in list(env):
    if key.upper().startswith('GIT_'):del env[key]
env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_SYSTEM=os.devnull,GIT_TERMINAL_PROMPT='0')
env['PYTHONUTF8'] = '1'
env['PATH'] = str(G / 'usr/bin') + os.pathsep + env['PATH']
env['GIT_CEILING_DIRECTORIES'] = str(work)
events = []

def h(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(label, args, cwd=U, expected=0):
    p = subprocess.run([str(x) for x in args], cwd=cwd, env=env, capture_output=True, encoding='utf8', errors='replace')
    event = {'label': label, 'command_array': [str(x) for x in args], 'cwd': str(cwd), 'stdout': p.stdout, 'stderr': p.stderr, 'exit_status': p.returncode, 'expected_exit_status': expected}
    events.append(event)
    (U / 'TRANSACTION_EVENTS.json').write_text(json.dumps(events, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    assert p.returncode == expected, event
    return p

def msys(p):
    s = str(Path(p).resolve()).replace('\\', '/')
    return '/' + s[0].lower() + s[2:]

base = U / 'ORIGINAL_BASELINE.zip'
modified = U / 'MODIFIED_FILE.zip'
test = [sys.executable, '-B', U / 'check_workflow_contract_v10.py']
run('BASELINE', test + [base, U / 'same_input.json'], expected=3)
run('MODIFIED', test + [modified, U / 'same_input.json'])
rollback = U / 'ROLLBACK.sh'
rollback.write_text('#!/bin/sh\nset -eu\n[ "$#" -eq 1 ] || { printf "%s\\n" "Usage: ROLLBACK.sh TARGET_COPY" >&2; exit 64; }\n[ -f "$1" ] || { printf "%s\\n" "Target copy does not exist" >&2; exit 66; }\nhere=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\ncp -- "$here/ORIGINAL_BASELINE.zip" "$1"\nprintf "%s\\n" "ROLLBACK restored pristine baseline bytes"\n', encoding='utf8', newline='\n')
restored = work / 'restored_copy.zip'
shutil.copyfile(modified, restored)
run('ROLLBACK_EXECUTION', [G / 'usr/bin/sh.exe', msys(rollback), msys(restored)])
assert h(restored) == h(base)
run('ROLLBACK', test + [restored, U / 'same_input.json'], expected=3)

repository = work / 'diff_repository'
repository.mkdir(exist_ok=True)
local = repository / 'bundle.zip'
run('INIT_ISOLATED_DIFF', [G / 'cmd/git.exe', '-c', 'core.autocrlf=false', 'init', '--quiet'], repository)
shutil.copyfile(base, local)
run('STAGE_PRISTINE_BYTES', [G / 'cmd/git.exe', '-c', 'core.autocrlf=false', 'add', 'bundle.zip'], repository)
shutil.copyfile(modified, local)
patch = run('CREATE_BINARY_DIFF', [G / 'cmd/git.exe', '-c', 'core.autocrlf=false', 'diff', '--binary', '--full-index', '--', 'bundle.zip'], repository)
(U / 'DIFF_FILE.patch').write_text(patch.stdout, encoding='utf8', newline='\n')
reconstruction = work / 'reconstruction'
reconstruction.mkdir(exist_ok=True)
shutil.copyfile(base, reconstruction / 'bundle.zip')
run('PATCH_RECONSTRUCTION', [G / 'cmd/git.exe', '-c', 'core.autocrlf=false', 'apply', '--binary', U / 'DIFF_FILE.patch'], reconstruction)
assert h(reconstruction / 'bundle.zip') == h(modified)

originals = json.loads((U / 'BASELINE_MANIFEST.json').read_text('utf8'))
assert all(h(x['original']) == x['sha256'] for x in originals)
result = {'status': 'PASS', 'kind': 'configuration_contract_not_quality_score', 'same_input': str(U / 'same_input.json'), 'changed_fields': ['SKILL research/audit/edit/resume routing', 'contract conditional contribution ranking', 'TOML single-contract loading', 'conditional model design and verified-status asset map'], 'baseline': {'stdout_status': 'UNMET_NEW_WORKFLOW_CONTRACT', 'exit_status': 3}, 'modified': {'stdout_status': 'PASS', 'exit_status': 0}, 'rollback': {'stdout_status': 'UNMET_NEW_WORKFLOW_CONTRACT', 'exit_status': 3}, 'old_skill_not_declared_scientifically_invalid': True, 'baseline_hash': h(base), 'modified_hash': h(modified), 'restored_hash': h(restored), 'restored_hash_equals_baseline': h(restored) == h(base), 'patch_exact_reconstruction': True, 'six_original_files_unchanged': True, 'events': events, 'utc': dt.datetime.now(dt.timezone.utc).isoformat()}
result['execution_file_identity'] = [{'path':str(p),'sha256':h(p),'bytes':Path(p).stat().st_size} for p in [Path(sys.executable),Path(__file__),U/'check_workflow_contract_v10.py',G/'cmd/git.exe',G/'usr/bin/sh.exe',G/'usr/bin/dirname.exe',G/'usr/bin/cp.exe']]
result['changed_fields'].append('general BLP literature-module integration and construction/compatibility protocol; explicit general agent')
(U / 'VERIFICATION.txt').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
roles = []
for name in ['MODIFIED_FILE.zip', 'DIFF_FILE.patch', 'VERIFICATION.txt', 'ROLLBACK.sh']:
    roles.append({'role': name, 'path': str(U / name), 'sha256': h(U / name), 'bytes': (U / name).stat().st_size, 'reopened': True})
(U / 'UPGRADE_FOUR_ROLES_REOPEN.json').write_text(json.dumps(roles, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'status': result['status'], 'same_input_exits': [3, 0, 3], 'rollback_exit': 0, 'restored_hash_equals_baseline': True, 'patch_exact_reconstruction': True, 'six_original_files_unchanged': True, 'roles': roles}, ensure_ascii=False))
