from pathlib import Path
import os,json,sys
print(json.dumps({'cwd':os.getcwd(),'payload':Path(sys.argv[1]).read_text('utf8')}))
