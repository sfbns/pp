import sys,time
label_weight = 0.6
time.sleep(5)
print(label_weight)
sys.exit(7)
