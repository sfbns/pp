from pathlib import Path
import json,hashlib,tomllib
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=Path(__file__).parent;C=U/'candidate_v9';D=U/'dependencies_v6'
def h(b):return hashlib.sha256(b).hexdigest()
l=json.loads((C/'skills/blp-model-building/references/文献模块来源账本.json').read_text('utf8'));dm=json.loads((D/'MANIFEST.json').read_text('utf8'));registered={x['path']:x for x in dm['files']};rs=[];excerpts=[]
for node in l['nodes']:
 print('NODE',node['node_id'],node['title'],node['permitted_use'])
 for src in node['sources']:
  p=D/src['snapshot_path'];raw=p.read_bytes();lines=raw.decode('utf-8-sig').splitlines();a,b=src['line_start'],src['line_end'];text='\n'.join(lines[a-1:b]);variants={h(text.encode()),h((text+'\n').encode())};assert p.is_file() and src['snapshot_path'] in registered and h(raw)==src['sha256']==registered[src['snapshot_path']]['sha256'];assert 1<=a<=b<=len(lines) and lines[a-1]==src['first_line'] and lines[b-1]==src['last_line'] and src['anchor_sha256_utf8_lf'] in variants
  rs.append({'node_id':node['node_id'],'snapshot_path':str(p),'line_start':a,'line_end':b,'sha256':h(raw),'anchor_sha256_utf8_lf':src['anchor_sha256_utf8_lf'],'all_matched':True,'source_status':src['source_status']});excerpts.append('NODE '+node['node_id']+' FILE '+str(p)+' LINES '+str(a)+'-'+str(b)+'\n'+text)
out={'nodes':len(l['nodes']),'anchors':len(rs),'anchor_lines_total':sum(x['line_end']-x['line_start']+1 for x in rs),'all_matched':True,'rows':rs,'scope':'identity and exact frozen line-ranges; source_status is historical technical/card synthesis, not fresh original reading'};(R/'source_anchor_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(R/'source_excerpts.txt').write_text('\n\n'.join(excerpts)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in out.items() if k!='rows'},ensure_ascii=False));print('CONFIG',tomllib.loads((C/'agents/blp-professor.toml').read_text('utf8'))['name'])
