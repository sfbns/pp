import sys
label_weight = 0.8
sys.stdout.buffer.write(b"\xff"+str(label_weight).encode()+b"\n")
sys.stderr.buffer.write(b"\xfe stderr\n")
