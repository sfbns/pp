from pathlib import Path
import json,hashlib,statistics,zipfile
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=U/'review/v8_support/independent_run_01'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text('utf8'))
J=U/'review/delta_review_v8.json';M=U/'review/delta_review_v8.md';r=j(J)
r['errors_and_corrections'].append({'source':str(R/'write_review_v8_initial.py'),'tool_chunk':'103c37','first_actual_exit':1,'error':'reviewer-generated anchor lookup used nonexistent def verify_manifest; report files not yet written','correction':'retain initial script, use actual def verify_tree and exact preregistration scope anchor','corrected_actual_exit':0,'corrected_tool_chunk':'f710d0'})
J.write_text(json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
md=M.read_text('utf8');md+='\n评审记录生成首错：锚名误写，工具103c37实际exit1；初稿脚本保留，改真实函数/范围锚后f710d0实际exit0。不是候选执行错误，未改任何源或旧分。\n';M.write_text(md,encoding='utf8')
# Narrow an inherited wording: own historical independent judgments were read;
# author scores/self-review were not. This does not alter candidate evidence.
p=R/'source_and_formula_checks.json';s=j(p);s['scope']='No author self-review, author target/old author scores, Claude body or unregistered paper opened; own independent historical review is reused only as explicitly scoped same-reviewer evidence';p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
r=j(J);md=M.read_text('utf8');spec=j(U/'review_inputs/V3_REVIEW_SPEC.json');criteria=[x['criterion'] for x in spec['criteria_per_component']]
assert r['candidate_path']==str(U/'candidate_v8') and r['author_target_or_self_review_opened'] is False and r['fatal_errors']==[]
assert r['component_minimums']=={'project_skill':82,'agent_config':79}
for comp,rows in r['scores'].items():
 assert len(rows)==21 and [x['criterion'] for x in rows]==criteria and round(statistics.mean(x['score'] for x in rows),2)==r['component_means'][comp]
 for x in rows:
  assert type(x['score']) is int and 0<=x['score']<=100 and x['reason'] and x['anchors']
  for a in x['anchors']:assert Path(a['path']).is_absolute() and 1<=a['line_start']<=a['line_end']<=len(Path(a['path']).read_text('utf-8-sig').splitlines())
counts={}
for label,root,mp,pin,count in [('candidate',U/'candidate_v8',U/'CANDIDATE_V8_MANIFEST.json','fa7e5badd651fa678eefc9756566f945826c53d17775f26a383dc3a1b3129538',17),('dependency',U/'dependencies_v6',U/'dependencies_v6/MANIFEST.json','d56e07903ec04c73e04235a3752132020f676a429bd9c9796b11d33d3bb57d8c',82),('behavior',U,U/'BEHAVIOR_V8_FREEZE.json','8e643a56b703defdbd51474657180a535b2f147393045688f2ddf840e83fa2a0',543)]:
 assert h(mp)==pin;v=j(mp);rows=v if isinstance(v,list) else v['files'];assert len(rows)==count
 for row in rows:assert h(root/row['path'])==row['sha256'] and (root/row['path']).stat().st_size==row['bytes']
 counts[label]=len(rows)
for row in r['four_role_reopen']:
 p=Path(row['absolute_path']);assert h(p)==row['sha256'] and p.read_bytes()==Path(row['reviewer_snapshot']).read_bytes()
 json.loads(p.read_text('utf8')) if p.name=='VERIFICATION.txt' else None
expected={'delta_review_v5.json':'0c0b7aa0c065fca71df9ff0d0f2082a6798980921e0e704542b247ca754ba512','delta_review_v5.md':'49267db63180690b9e12aa6e4c74ace658d0d461acf60c0220d89c03d31836a1','delta_review_v6.json':'28698d9102832e30a1e712aa48f82e7e22d5742196dd878becc7405c2d673742','delta_review_v6.md':'2b796d016a5077e5a2efd6e5c8a79b6700355d5ad43caac3c2f40fb6e2d534e0'}
for name,pin in expected.items():assert h(U/'review'/name)==pin
for row in r['original_six_live_byte_checks']:assert h(Path(row['path']))==row['sha256']
z=zipfile.ZipFile(U/'ORIGINAL_BASELINE.zip');origrows=[x for x in j(U/'dependencies_v6/MANIFEST.json')['files'] if x['path'].startswith('baseline_R6/')];assert len(z.namelist())==len(origrows)==6
for row in origrows:assert hashlib.sha256(z.read(row['path'].removeprefix('baseline_R6/'))).hexdigest()==row['sha256']
assert h(U/'ORIGINAL_BASELINE.zip')=='8d19d218a0ac490de4c6febd3a54282339ea50aff234e4afd95703d8a672d011'
tx=j(R/'transaction_checks/continued_results.json');assert tx['all_passed'] and len(tx['checks'])==13
bc=j(R/'behavior_checks.json');assert bc['all_passed'] and len(bc['checks'])==14 and bc['raw_transaction_streams_checked']==40
rt=j(R/'root_v8_transaction/evidence.json');assert rt['behaviors']==[3,0,3] and rt['real_SH_exit']==0 and rt['restored_equals_original'] and rt['patch_exact'] and rt['ZIP_exact_current_17_manifest']
out={'completed':True,'reports_reopened':[{'absolute_path':str(p),'sha256':h(p),'bytes':p.stat().st_size} for p in [J,M]],'all42_scores_and_real_anchors_valid':True,'means':r['component_means'],'minimums':r['component_minimums'],'fatal_errors':0,'frozen_counts_current_unchanged':counts,'root_four_roles_reopened':r['four_role_reopen'],'root_behaviors':[3,0,3],'root_actual_SH_exit':0,'root_patch_exact':True,'original_six_live_and_ZIP_bytes_unchanged':True,'old_v5_v6_independent_reviews_unchanged':True,'scientific_behavior_scope':'v6 inherited, not new v8','A_D_v8_raw_streams_matches':40,'source_bound_object_stable':True,'all_first_errors_retained':True}
(R/'TERMINAL_VALIDATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(out,ensure_ascii=False))
