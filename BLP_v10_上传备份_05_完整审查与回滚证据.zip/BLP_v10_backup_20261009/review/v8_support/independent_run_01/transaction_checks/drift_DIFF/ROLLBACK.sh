#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then printf '%s\n' 'usage: ROLLBACK.sh TARGET_COPY' >&2; exit 2; fi
here=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
case $1 in /*) destination=$1 ;; *) destination=$PWD/$1 ;; esac
cp "$here/PRISTINE.py" "$destination"
printf '%s\n' 'restored pristine bytes'
