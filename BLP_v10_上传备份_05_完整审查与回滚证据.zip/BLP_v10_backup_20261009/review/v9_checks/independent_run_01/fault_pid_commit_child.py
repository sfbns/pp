from pathlib import Path
import importlib.util,sys,os,json,time,hashlib
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=Path(__file__).parent;O=R/'pid_commit_failure';O.mkdir();source=O/'source.py'
source.write_bytes(b'import sys,time\nlabel_weight = 0.6\ntime.sleep(5)\nprint(label_weight)\nsys.exit(7)\n')
script=U/'candidate_v9/scripts/verified_text_edit.py';before=hashlib.sha256(script.read_bytes()).hexdigest();spec=importlib.util.spec_from_file_location('frozen_v9_writer',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
realreplace=m.os.replace;realpopen=m.subprocess.Popen;processes=[];injections=[];counts={}
def observe_popen(*args,**kwargs):
 p=realpopen(*args,**kwargs);processes.append((p,args[0]));return p
m.subprocess.Popen=observe_popen
args=m.parser().parse_args(['--source',str(source),'--old','label_weight = 0.6','--new','label_weight = 0.8','--command-json',json.dumps([sys.executable,'-B','{TARGET}']),'--out',str(O/'transaction')])
t=m.Transaction(args)
def faultreplace(a,b):
 if t.ledger and t.ledger.get('command_execution'):
  e=t.ledger['command_execution'][-1];key=e['step']
  if key in ['BASELINE','MODIFIED','ROLLBACK'] and e.get('started') and not e.get('finished') and e.get('pid') and counts.get(key,0)<4:
   counts[key]=counts.get(key,0)+1;injections.append({'step':key,'attempt':counts[key],'pid':e['pid'],'at_monotonic':time.monotonic(),'source':'reviewer injected os.replace WinError5, not real OS root cause'})
   x=PermissionError(13,'reviewer injected persistent PID commit failure');x.winerror=5;raise x
 return realreplace(a,b)
m.os.replace=faultreplace
start=time.monotonic();result=t.run();returned=time.monotonic();alive=[{'pid':p.pid,'poll_at_return':p.poll(),'command':c} for p,c in processes]
receipt={'frozen_transaction_return':result,'elapsed_to_return_seconds':returned-start,'process_observations_at_return':alive,'injections':injections,'frozen_script_sha256_before':before,'frozen_script_sha256_after':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'real children plus explicitly injected repeated WinError5 at PID ledger commit; no frozen/source/root modification'}
(O/'AT_RETURN.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=True))
after=[]
for p,c in processes:after.append({'pid':p.pid,'actual_wait_exit':p.wait(timeout=15),'command':c})
receipt['actual_waits_after_false_completion']=after;v=json.loads((O/'transaction/VERIFICATION.txt').read_text('utf8'));receipt['persisted_status']=v['status'];receipt['persisted_behaviors']=v['behaviors'];receipt['persisted_behavior_events']=[x for x in v['command_execution'] if x['step'] in ['BASELINE','MODIFIED','ROLLBACK']];receipt['actual_behavior_streams_after_wait']={k:{'stdout_hex':Path(x['stdout_path']).read_bytes().hex(),'stderr_hex':Path(x['stderr_path']).read_bytes().hex()} for k,x in v['behaviors'].items()};(O/'FINAL_OBSERVATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
