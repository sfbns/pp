"""Restore byte-identical PDF test copies omitted from the compact audit ZIP."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import shutil

p=argparse.ArgumentParser()
p.add_argument('--root',default=str(Path(__file__).resolve().parent))
a=p.parse_args()
root=Path(a.root).resolve()
def safe(rel):
    q=PurePosixPath(rel)
    if q.is_absolute() or '..' in q.parts or '\\' in rel or ':' in rel:
        raise ValueError('unsafe map path')
    path=(root/rel).resolve()
    if not path.is_relative_to(root):raise ValueError('map outside audit root')
    return path
def h(path):return hashlib.sha256(path.read_bytes()).hexdigest()
d=json.loads((root/'AUDIT_DUPLICATE_BYTE_MAP.json').read_text('utf8'))
count=0
for row in d['omitted_duplicate_pdfs']:
    source,target=safe(row['retained_path']),safe(row['omitted_path'])
    assert h(source)==row['sha256']
    if target.exists():
        assert h(target)==row['sha256'],'refuse to overwrite different bytes'
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    assert h(target)==row['sha256']
    count+=1
print(json.dumps({'status':'PASS','restored_or_matched':count,'scope':'byte-identical isolated PDF copies only; no new reading or rerun claim'}))
