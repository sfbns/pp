import numpy as np,json
from pathlib import Path
R=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008\review\v9_checks\independent_run_01')
def prob(p,a):
 v=np.array([a,.4])-p;ex=np.exp(v);return ex/(1+ex.sum())
def solve(a):
 c=np.array([.5+.1*a,.6]);p=c+1.3
 for _ in range(1000):
  s=prob(p,a);pn=.5*p+.5*(c+1/(1-s))
  if max(abs(pn-p))<1e-14:return pn
  p=pn
 raise Exception('nonconvergence')
a=.7;ep=1e-5;p=solve(a);s=prob(p,a);c=.5+.1*a;partial=(p[0]-c)*s[0]*(1-s[0])-.1*s[0]
def profit(a):
 p=solve(a);return (p[0]-.5-.1*a)*prob(p,a)[0]
total=(profit(a+ep)-profit(a-ep))/(2*ep);dp=(solve(a+ep)-solve(a-ep))/(2*ep);rival=(p[0]-c)*s[0]*s[1]*dp[1]
row={'counterexample_scope':'two single-product firms, quality chosen before Bertrand pricing; demonstrates stage-timing limitation, NOT a claim the minimal fixed-attribute model fails','partial_fixed_price_attribute_derivative':float(partial),'reduced_profit_total_derivative':float(total),'rival_price_response_term':float(rival),'own_price_FOC':float(s[0]-(p[0]-c)*s[0]*(1-s[0])),'decomposition_error':float(total-partial-rival),'candidate_boundary':'protocol line143 lists components rather than complete stage-game FOC; future A implementation must specify price response and equilibrium timing; E/F displayed D_a is not expanded'}
assert abs(total-partial)>.001 and abs(total-partial-rival)<1e-9
(R/'attribute_stage_timing_check.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(row,ensure_ascii=False))
