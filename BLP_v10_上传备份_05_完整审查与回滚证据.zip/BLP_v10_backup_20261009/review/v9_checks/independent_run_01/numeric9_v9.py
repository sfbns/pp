from pathlib import Path
import json,hashlib,subprocess,datetime,sys
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=U/'review/v9_checks/independent_run_01/numeric9';R.mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((U/'execution_v9_numeric/COMMAND_EVENTS.json').read_text('utf8'));events=[]
for e in rows:
 label=e['label'];cwd=R/label;cwd.mkdir();cmd=e['command_array'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (cwd/'stdout.bin').open('wb') as out,(cwd/'stderr.bin').open('wb') as err:
  p=subprocess.Popen(cmd,cwd=cwd,stdout=out,stderr=err,stdin=subprocess.DEVNULL);code=p.wait(timeout=240)
 d={'label':label,'command_array':cmd,'cwd':str(cwd),'pid':p.pid,'started':True,'finished':True,'started_at_utc':start,'exit_status':code,'expected_exit':e['exit_status'],'stdout_sha256':h(cwd/'stdout.bin'),'stderr_sha256':h(cwd/'stderr.bin'),'literal_stdout':(cwd/'stdout.bin').read_bytes().decode('utf8',errors='replace'),'literal_stderr':(cwd/'stderr.bin').read_bytes().decode('utf8',errors='replace')};events.append(d)
 (R/'caller_events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print(label,code,'expected',e['exit_status'])
assert len(events)==9 and all(r['exit_status']==r['expected_exit'] for r in events)
(R/'result.json').write_text(json.dumps({'all_expected_exits':True,'nine_events':len(events),'scope':'five registered teaching selftests, Nevo public example and three explicit injected stage-fail negatives; no current-project or all-module estimator certification','venv_boundary':'numpy2.5.3/pandas3.0.6/pyblp1.2.0 distinct from guard numpy2.3.3'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
