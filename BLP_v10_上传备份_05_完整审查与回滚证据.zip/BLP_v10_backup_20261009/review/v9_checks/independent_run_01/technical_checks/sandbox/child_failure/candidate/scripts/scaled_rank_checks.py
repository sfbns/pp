import sys
print('deliberate independent failure',file=sys.stderr)
sys.exit(9)
