from pathlib import Path
import subprocess,hashlib,json,shutil,zipfile,os
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008'); R=U/'review/v9_checks/independent_run_01/root_v9_transaction'; R.mkdir(exist_ok=False)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sp(p):return '/'+p.drive[0].lower()+str(p)[2:].replace('\\','/')
PY=Path(r'C:\Users\于舒奕\AppData\Local\Programs\Python\Python312\python.exe'); inv=json.loads((U/'candidate_v9/skills/blp-project-professor/references/runtime-environment.json').read_text('utf8'));tools={}
for row in inv['rollback_environment']['executables']:
 p=Path(row['absolute_path']);assert h(p)==row['sha256'] and p.stat().st_size==row['bytes'];tools[row['name']]=p
env=dict(os.environ);env['PATH']=os.pathsep.join(inv['rollback_environment']['path_entries']+[env.get('PATH','')]);env['LC_ALL']='C';env['GIT_CONFIG_NOSYSTEM']='1';env['GIT_CONFIG_GLOBAL']=os.devnull;env['GIT_CONFIG_SYSTEM']=os.devnull
roles=[]
for name in ['MODIFIED_FILE.zip','DIFF_FILE.patch','VERIFICATION.txt','ROLLBACK.sh']:
 p=U/name;raw=p.read_bytes();roles.append({'role':name,'absolute_path':str(p),'sha256':h(p),'bytes':len(raw),'reopened':True});(R/name).write_bytes(raw)
for name in ['ORIGINAL_BASELINE.zip','same_input.json','check_workflow_contract.py']:(R/name).write_bytes((U/name).read_bytes())
manifest=json.loads((U/'CANDIDATE_V9_MANIFEST.json').read_text('utf8'));z=zipfile.ZipFile(R/'MODIFIED_FILE.zip'); archive_exact=set(z.namelist())=={r['path'] for r in manifest} and all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] and len(z.read(r['path']))==r['bytes'] for r in manifest);assert archive_exact,'Root artifact not frozen v9'
events=[]
def run(label,cmd,cwd=R):
 p=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,capture_output=True,timeout=120);(R/(label+'.stdout.bin')).write_bytes(p.stdout);(R/(label+'.stderr.bin')).write_bytes(p.stderr);e={'label':label,'command_array':list(map(str,cmd)),'cwd':str(cwd),'exit_status':p.returncode,'literal_stdout_utf8_replace':p.stdout.decode('utf8',errors='replace'),'literal_stderr_utf8_replace':p.stderr.decode('utf8',errors='replace')};events.append(e);return e
for label,archive in [('BASELINE',R/'ORIGINAL_BASELINE.zip'),('MODIFIED',R/'MODIFIED_FILE.zip')]:run(label,[PY,'-B',R/'check_workflow_contract.py',archive,R/'same_input.json'])
restored=R/'restored_copy.zip';shutil.copyfile(R/'MODIFIED_FILE.zip',restored);run('ROLLBACK_SH',[tools['sh'],sp(R/'ROLLBACK.sh'),sp(restored)]);run('ROLLBACK',[PY,'-B',R/'check_workflow_contract.py',restored,R/'same_input.json'])
repo=R/'patch_repo';repo.mkdir();shutil.copyfile(R/'ORIGINAL_BASELINE.zip',repo/'bundle.zip');run('PATCH_INIT',[tools['git'],'-c','core.autocrlf=false','init','--quiet'],repo);run('PATCH_APPLY',[tools['git'],'-c','core.autocrlf=false','apply','--binary',R/'DIFF_FILE.patch'],repo)
result={'root_roles_reopened':roles,'snapshot_root':str(R),'events':events,'behaviors':[e['exit_status'] for e in events if e['label'] in ['BASELINE','MODIFIED','ROLLBACK']],'real_SH_exit':events[2]['exit_status'],'restored_equals_original':restored.read_bytes()==(R/'ORIGINAL_BASELINE.zip').read_bytes(),'patch_exact':(repo/'bundle.zip').read_bytes()==(R/'MODIFIED_FILE.zip').read_bytes(),'ZIP_exact_current_22_manifest':archive_exact,'original_root_hash':h(U/'ORIGINAL_BASELINE.zip'),'snapshot_original_hash':h(R/'ORIGINAL_BASELINE.zip'),'root_source_roles_unchanged':all(h(Path(r['absolute_path']))==r['sha256'] for r in roles),'scope':'3/0/3 metadata contract only, not research quality'}
(R/'evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k not in ['events','root_roles_reopened']},ensure_ascii=False))
