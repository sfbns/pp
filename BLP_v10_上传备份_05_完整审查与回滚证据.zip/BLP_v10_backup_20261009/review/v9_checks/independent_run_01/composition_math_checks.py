from pathlib import Path
import json, numpy as np
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=U/'review/v9_checks/independent_run_01';checks=[]
def check(n,c,o):checks.append({'name':n,'passed':bool(c),'observed':o})
v=np.array([.4,-.2,.7]);groups=[[0,1],[2]]
def gev(v,lam):
 inc=np.array([np.exp(v[g]/lam).sum()**lam for g in groups]);den=1+inc.sum();p=np.zeros(3)
 for a,g in zip(inc,groups):p[g]=a/den*np.exp(v[g]/lam)/np.exp(v[g]/lam).sum()
 return np.log(den),p
G,p=gev(v,.45);ep=1e-6;grad=np.array([(gev(v+ep*np.eye(3)[j],.45)[0]-gev(v-ep*np.eye(3)[j],.45)[0])/(2*ep) for j in range(3)])
check('GEV_surplus_gradient_is_correct_nested_probability',max(abs(grad-p))<1e-9,{'max_error':float(max(abs(grad-p)))})
plain=np.exp(v)/(1+np.exp(v).sum());check('rho_zero_exact_RC_kernel_and_welfare',max(abs(gev(v,1)[1]-plain))<1e-15 and abs(gev(v,1)[0]-np.log(1+np.exp(v).sum()))<1e-15,{'probability_error':float(max(abs(gev(v,1)[1]-plain)))})
rng=np.random.default_rng(3901);N=500000;lam=.45;ang=rng.uniform(1e-12,np.pi-1e-12,N);E=rng.exponential(size=N)
S=np.sin(lam*ang)/np.sin(ang)**(1/lam)*(np.sin((1-lam)*ang)/E)**((1-lam)/lam)
u=np.column_stack([v[0]+lam*(np.log(S)+rng.gumbel(size=N)),v[1]+lam*(np.log(S)+rng.gumbel(size=N)),rng.gumbel(size=N)])
rank=np.argsort(u,axis=1);joint=float(np.mean((rank[:,-1]==0)&(rank[:,-2]==1)))
inc=(np.exp(v[0]/lam)+np.exp(v[1]/lam))**lam;pj=inc/(1+inc)*np.exp(v[0]/lam)/(np.exp(v[0]/lam)+np.exp(v[1]/lam));wrong=float(pj*np.exp(v[1])/(1+np.exp(v[1])))
check('correlated_nested_same_shock_ranking_refutes_deleted_marginal_product',abs(joint-wrong)>.02,{'true_nested_ranking_MC':joint,'incorrect_logit_factorization':wrong,'draws':N,'Monte_Carlo_not_exact_identity':True})
y=np.array([4.,7.,12.]);w=np.array([.2,.3,.5]);prices=np.array([1.3,2.7]);x=np.array([[.3,.6,.5],[.7,.2,.4]])
def shares(p):
 val=np.log(y-p[:,None])+x;out=np.log(y);ex=np.exp(val);den=np.exp(out)+ex.sum(axis=0);return ex/den
P=shares(prices);J=np.array([[-np.sum(w/(y-prices[k])*P[j]*((j==k)-P[k])) for k in range(2)] for j in range(2)])
fd=np.column_stack([(shares(prices+ep*np.eye(2)[k])@w-shares(prices-ep*np.eye(2)[k])@w)/(2*ep) for k in range(2)])
check('income_effect_asymmetric_price_J_matches_derivative',max(abs(J-fd).flat)<1e-9 and abs(J[0,1]-J[1,0])>1e-3,{'max_error':float(max(abs(J-fd).flat)),'asymmetry':float(J[0,1]-J[1,0])})
tau=np.array([1.1,1.4]);d=np.diag(tau);Jr=J@d;sr=P@w;mark=np.linalg.solve(-Jr.T,sr);wrongres=sr+Jr@mark
check('tax_chain_transpose_correct_wrong_orientation_rejected',max(abs(sr+Jr.T@mark))<1e-12 and max(abs(wrongres))>.005,{'correct_residual':float(max(abs(sr+Jr.T@mark))),'wrong_residual':float(max(abs(wrongres)))})
# Two-dimensional affine equilibrium has analytic implicit response.
A=np.array([[1.2,.1],[.2,1.1]]);B=np.array([[.2,.05],[.03,.25]]);D=np.array([[.4,.1],[.05,.3]]);Qp=np.array([[-.3,.1],[.05,-.2]]);z=np.array([.3,.2])
def net(p):return np.linalg.solve(A-B@D,z+B@Qp@p)
dNp=np.linalg.solve(A-B@D,B@Qp);Nfd=np.column_stack([(net(prices+ep*np.eye(2)[k])-net(prices-ep*np.eye(2)[k]))/(2*ep) for k in range(2)])
check('network_multivariate_implicit_derivative',max(abs(dNp-Nfd).flat)<1e-10,{'max_error':float(max(abs(dNp-Nfd).flat)),'minimum_feedback_singular_value':float(np.linalg.svd(A-B@D,compute_uv=False)[-1])})
# Known prior and independent label variation admit two directions; free scale confounds gamma.
prior=np.array([1.,2.,.5,1.7]);gap=np.array([.2,-.3,.8,.4]);g=.8;o=.6;k=1.2;gh=prior+o*gap
J2=np.column_stack([-gh,-g*gap]);J3=np.column_stack([-k*gh,-g*k*gap,-g*gh])
check('capitalization_belief_known_scale_can_rank_unknown_scale_cannot',np.linalg.matrix_rank(J2)==2 and np.linalg.matrix_rank(J3)==2,{'known_scale_rank':int(np.linalg.matrix_rank(J2)),'unknown_scale_rank':int(np.linalg.matrix_rank(J3)),'parameters_unknown_scale':3,'scope':'primitive index derivative geometry, not empirical IV rank'})
# Income CV ex ante root; cardinal money dividing by any alpha is not used.
def ev(y,p):return np.log(np.exp(np.log(y))+np.exp(np.log(y-p)+.5))
y0=8.;p0=2.;p1=3.;base=ev(y0,p0);lo,hi=0.,2.
for _ in range(100):
 mid=(lo+hi)/2
 if ev(y0+mid,p1)>base:hi=mid
 else:lo=mid
cv=(lo+hi)/2;check('income_CV_root_matches_selected_ex_ante_normalization',abs(ev(y0+cv,p1)-base)<1e-13 and 0<cv<1,{'required_compensation':cv,'root_residual':float(ev(y0+cv,p1)-base)})
# A discrete Bellman fixed point reduces to identical static choice values at beta zero.
flow=np.array([[.1,.6,.2],[.4,.2,.8]]);trans=np.array([[[.8,.2],[.3,.7]],[[.5,.5],[.2,.8]],[[.7,.3],[.4,.6]]]);V=np.zeros(2);beta=.7
for _ in range(500):
 choice=flow+beta*np.column_stack([trans[a]@V for a in range(3)]);Vnew=np.log(np.exp(choice).sum(axis=1))
 if max(abs(Vnew-V))<1e-13:break
 V=Vnew
check('Bellman_beta_zero_static_same_menu_degeneration',np.allclose(flow+0*np.column_stack([trans[a]@V for a in range(3)]),flow),{'scope':'same state/menu/outside held; no claim different purchase opportunities degenerate'})
assert all(x['passed'] for x in checks),checks
(R/'composition_math_checks.json').write_text(json.dumps({'scope':'independent synthetic algebra/Monte Carlo falsifiers, not empirical model identification or paper-formula revalidation','checks':checks},ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(checks,ensure_ascii=False))
