import sys
label_weight = 0.8
a,b=map(float,sys.argv[1:3])
print(f"{b+label_weight*(a-b):.6f}")
