from pathlib import Path
import sys,subprocess,json,hashlib,base64
U=Path(r'D:\codex\output\blp_agent_skill_upgrade_20261008');R=Path(__file__).parent
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for root,mp,pin,n in [(U/'candidate_v9',U/'CANDIDATE_V9_MANIFEST.json','f9231fa0e7461a0a4190caca7fe5feee45e71186f266753f1da27d5f6c79c7a8',22),(U/'dependencies_v6',U/'dependencies_v6/MANIFEST.json','d56e07903ec04c73e04235a3752132020f676a429bd9c9796b11d33d3bb57d8c',82)]:
 assert h(mp)==pin;v=json.loads(mp.read_text('utf8'));rows=v if isinstance(v,list) else v['files'];assert len(rows)==n
 for row in rows:assert h(root/row['path'])==row['sha256'] and (root/row['path']).stat().st_size==row['bytes']
cmd=[sys.executable,'-I','-B',str(R/'fault_pid_commit_child.py')];p=subprocess.run(cmd,cwd=R,capture_output=True,timeout=30);e={'command_array':cmd,'cwd':str(R),'exit_status':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode(),'literal_stdout_utf8_replace':p.stdout.decode('utf8',errors='replace'),'literal_stderr_utf8_replace':p.stderr.decode('utf8',errors='replace')};(R/'pid_commit_fault_caller_event.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(e,ensure_ascii=False))
if p.returncode==0:
 o=json.loads((R/'pid_commit_failure/FINAL_OBSERVATION.json').read_text('utf8'));print(json.dumps({'status':o['persisted_status'],'behavior_exits':{k:v['exit_status'] for k,v in o['persisted_behaviors'].items()},'behavior_events':[{k:x.get(k) for k in ['step','pid','started','finished','exit_status','launch_error']} for x in o['persisted_behavior_events']],'actual_behavior_child_waits':[x for x in o['actual_waits_after_false_completion'] if any(y['pid']==x['pid'] for y in o['persisted_behavior_events'])],'injection_count':len(o['injections']),'script_unchanged':o['frozen_script_sha256_before']==o['frozen_script_sha256_after']},ensure_ascii=False))
